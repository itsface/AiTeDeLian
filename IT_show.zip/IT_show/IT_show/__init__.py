import pymysql
pymysql.install_as_MySQLdb()
home = r"C:\Users\33275\AppData\Local\Programs\Python\Python36\Lib\site-packages"